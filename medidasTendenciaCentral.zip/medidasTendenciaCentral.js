var datosAgregados = [];


function procesarDatos(){
    const inputDato = document.getElementById("dato");
    const btnAgregar = document.getElementById("add");
    dato = inputDato.value;
    
    const alert = document.getElementById("alert");
    if(dato != ''){
        agregarDato(dato);
        alert.innerHTML = "<style>#goodAlert{color:green;with:520px;}</style><p id='goodAlert'>Dato agregado correctamente</p>"
        inputDato.value = '';
        mostrarDatosPantalla(datosAgregados);
    }
    else{
        alert.innerHTML ="<style>#badAlert{color:red;font-weight:bold;}#dato{border:1px solid red;}</style><p id='badAlert'>Debe ingresar un dato en el campo</p>"
    }

    inputDato.focus();
    return datosAgregados;

}

function agregarDato(dato){
    datosAgregados.push(dato);
    return datosAgregados;
}
function mostrarDatosPantalla(datosAgregados){
    const listaHtml = document.getElementById('listaDatos'); 
    
    // listaHtml.innerHTML = " " + datosAgregados;
    listaHtml.innerText = datosAgregados.toString()
}

//Hallar promedio
function promedio(){
    const mostrar = document.getElementById("resultado");
     const sumaLista= datosAgregados.reduce(
         function (valorAcumulado= 0,nuevoElemento){
             var suma = Number(valorAcumulado) + Number(nuevoElemento); 
             return suma;
         }
     )
    
    console.log( typeof sumaLista);
    
    var nuevaLista = []
    nuevaLista = datosAgregados.map((elemento)=>{
        return elemento * 1;
    })
    
    console.log(nuevaLista.lenght);
    //const promedio = sumaLista/longitudDatos;
    
    //console.log(promedio);

    // mostrar.innerText = '';
    // mostrar.innerText ="El promedio de los datos es: " + promedio;

}

//Hallar Mediana
function mediana(){

}

function esPar(numero){
    return (numero % 2 === 0);
}

function calcularMediana(lista){
    const mitad = parseInt(lista.lenght / 2);

    if(esPar(lista.lenght)){
        const personaMitad1 = lista[mitad - 1];
        const personaMitad2 = lista[mitad];

        const mediana = calcularPromedio([personaMitad1,personaMitad2]);
        return mediana;
    }else{
        const personaMitad = lista[mitad];

        return personaMitad;
    }
}

// const lista = [2,2,4,5,671,21,21,21,21,21,12];

// for(let i=0; i<lista.length;i++){
//     for(let j=0; j<lista.length;j++){
//         if(lista[j]>lista[j + 1 ]){
//             aux = lista[j];
//             lista[j] = lista[j+1];
//             lista[j+1] = aux;
//         }
//     }
// }

// let listaRepeticiones=[];
// let listaNumeros=[]; 

// for(let i = 0;i<lista.length;i++){
//     c=0;
//     for(let j=0;j<lista.length;j++){        
//         if(lista[i] === lista[j]){
            
//             c++;
//         }
//     }
//     if(!listaNumeros.includes(lista[i])){
//         listaRepeticiones.push(c)
//         listaNumeros.push(lista[i])
//     }
// }

// let indiceMayor = -1;

// for(let i=0;i<listaRepeticiones.length;i++){
    
//     if(i === 0){
//         indiceMayor = i;
//     }else if(listaRepeticiones[i]>listaRepeticiones[indiceMayor]){
//         indiceMayor= i;
//     }
// }

// console.log("La moda es: "+ listaNumeros[indiceMayor] +" la cantidad de veces que aparece es: "+ listaRepeticiones[indiceMayor]);
